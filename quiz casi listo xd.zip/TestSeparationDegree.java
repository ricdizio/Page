import junit.framework.TestCase;

public class TestSeparationDegree extends TestCase {


    public void testSeparationDegree1()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","john","judy"});
      String result = results[0];
      String expected = "1";
      assertEquals ("fallo prueba 1", expected, result);
    }

    public void testSeparationDegree2()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","john","katie"});
      String result = results[0];
      String expected = "1";
      assertEquals ("fallo prueba 2", expected, result);
    }

    public void testSeparationDegree3()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","peter","john"});
      String result = results[0];
      String expected = "1";
      assertEquals ("fallo prueba 3", expected, result);
    }

    public void testSeparationDegree4()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","mary","john"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 4", expected, result);
    }

    public void testSeparationDegree5()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","judy","katie"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 5", expected, result);
    }

    public void testSeparationDegree6()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","judy","peter"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 6", expected, result);
    }

    public void testSeparationDegree7()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","judy","judy"});
      String result = results[0];
      String expected = "0";
      assertEquals ("fallo prueba 7", expected, result);
    }

    public void testSeparationDegree8()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","mary","mary"});
      String result = results[0];
      String expected = "0";
      assertEquals ("fallo prueba 7", expected, result);
    }

    public void testSeparationDegree9()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","frank","judy"});
      String result = results[0];
      String expected = "-1";
      assertEquals ("fallo prueba 9", expected, result);
    }

    public void testSeparationDegree10()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","peter","larry"});
      String result = results[0];
      String expected = "-1";
      assertEquals ("fallo prueba 10", expected, result);
    }

    public void testSeparationDegree11()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","katie","judy"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 11", expected, result);
    }

    public void testSeparationDegree12()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad1.txt","peter","judy"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 12", expected, result);
    }

    public void testSeparationDegree13()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","0","190"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 13", expected, result);
    }

    public void testSeparationDegree14()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","67","190"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 14", expected, result);
    }

    public void testSeparationDegree15()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","5","101"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 15", expected, result);
    }

    public void testSeparationDegree16()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","5","100"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 16", expected, result);
    }

    public void testSeparationDegree17()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","5","20"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 17", expected, result);
    }

    public void testSeparationDegree18()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","4","100"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 18", expected, result);
    }

    public void testSeparationDegree19()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","4","101"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 19", expected, result);
    }

    public void testSeparationDegree20()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","4","96"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 20", expected, result);
    }

    public void testSeparationDegree21()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","22","37"});
      String result = results[0];
      String expected = "1";
      assertEquals ("fallo prueba 21", expected, result);
    }

    public void testSeparationDegree22()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","22","36"});
      String result = results[0];
      String expected = "1";
      assertEquals ("fallo prueba 22", expected, result);
    }

    public void testSeparationDegree23()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","22","39"});
      String result = results[0];
      String expected = "1";
      assertEquals ("fallo prueba 23", expected, result);
    }

    public void testSeparationDegree24()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","3","100"});
      String result = results[0];
      String expected = "1";
      assertEquals ("fallo prueba 24", expected, result);
    }

    public void testSeparationDegree25()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","6","100"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 25", expected, result);
    }

    public void testSeparationDegree26()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","45","100"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 26", expected, result);
    }

    public void testSeparationDegree27()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","57","100"});
      String result = results[0];
      String expected = "1";
      assertEquals ("fallo prueba 27", expected, result);
    }

    public void testSeparationDegree28()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","57","97"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 28", expected, result);
    }

    public void testSeparationDegree29()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","77","106"});
      String result = results[0];
      String expected = "2";
      assertEquals ("fallo prueba 29", expected, result);
    }

    public void testSeparationDegree30()
    { 
      String[] results = AbstractMainTests.executeMain("SeparationDegree", new String[]{"comunidad2.txt","37","93"});
      String result = results[0];
      String expected = "1";
      assertEquals ("fallo prueba 30", expected, result);
    }
}

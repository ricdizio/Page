
//Lab04 DFSSS
import java.util.*;
public class DepthFirstSearch {
    private boolean[] marked;    // marked[v] = is there an s-v path?
    private int count;           // number of vertices connected to s
    private List<Vertice> listaDeVertices;
    private Vertice inicial;
    ArrayList<String> nodos = new ArrayList<String>();
    private int seleccion;
    private List<Double> caminos = new ArrayList<Double>(); 
    public HashMap<String, Integer> markedV;



    public DepthFirstSearch(GrafoNoDirigido G, Vertice v, Integer q) {
        //this.listaDeVertices = G.vertices();
        this.markedV = new HashMap <String, Integer>();
        this.inicial = v;
        //this.seleccion = y;
        this.listaDeVertices = new LinkedList<Vertice>();
        this.listaDeVertices = G.vertices();
        //this.marked = new boolean[G.numeroDeVertices()];
        if(this.validateVertex(G,v)){
            this.dfs(G, v,q);
            //this.imprimir(G);
        }
     }

    private void dfs(GrafoNoDirigido G, Vertice v, int q) {
        this.count++;

        markedV.put(v.getId(),q);
        for (Vertice w : G.adyacentes(v.getId())) 
        {
            if (!(markedV.containsKey(w.getId()))) 
            {
                this.dfs(G, w,q+1);
            }
        }
    }
    public void marked(GrafoNoDirigido G, Vertice v) {

        if (validateVertex(G,v) == true) {
            this.marked[this.listaDeVertices.indexOf(v)] = true;
        }
    }

    public boolean VerificateMarked(GrafoNoDirigido G, Vertice v) {

        if (markedV.containsKey(v.getId())) {
            
            return true;

        }
        return false;
    }

    public int count() {
        return this.count;
    }

    private boolean validateVertex(GrafoNoDirigido G,Vertice v) {
         if (G.estaVertice(v.getId())) {
            return true;
           
        }
        else {
            throw new NoSuchElementException("El vertice con id " +v.getId() + " no se encuentra en el Grafo");
        }
    } 
}
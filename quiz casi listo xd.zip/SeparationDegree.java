import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.*;

class SeparationDegree
{
  public static void main(String[] args)
  {
  	// Creamos la instancia g de nuestro grafo
  	GrafoNoDirigido g = new GrafoNoDirigido();
  	//Cargamos el grafo
  	g.cargarGrafo(args[0]);

  	String persona_inicial = args[1];
  	String persona_final = args[2];

  	Vertice x = new Vertice(persona_inicial,persona_inicial);
  	Vertice y = new Vertice(persona_final,persona_final);

	if(g.estaVertice(persona_inicial) && g.estaVertice(persona_final))
	{
		int d = 0;
		DepthFirstSearch dfs = new DepthFirstSearch(g,x,d);
		boolean road = dfs.VerificateMarked(g,y);
		if(road) System.out.println(persona_inicial + " y " + persona_final + " se conocen");
		System.out.println("dis " + dfs.markedV.get(persona_final));
	}
	else
	{
		if(g.estaVertice(persona_inicial)) System.out.println("vertice " + persona_inicial + " not found");
		else System.out.println("vertice " + persona_final + " not found");
		
	}

  	
    System.out.println("Se cargo el grafo");
  }
}
